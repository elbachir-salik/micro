
export const checkoutFormStyles = theme => ({
    root: {
        '& > *': {
            marginLeft: theme.spacing(3),
        },
    },
    formControlLabel: {
        width: "inherit"
    }
});
